﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour {
    public Text timerText; // test 

    //public float mainTimer;
    public float timer;
     public bool canCount = true;     public bool doOnce = false; 

    private bool isDead = false;

    // Use this for initialization
    void Start () {
        timer = 180;
	}
	
	// Update is called once per frame
	void Update () {

        if (isDead)
            return;
        if (timer >= 0.0f && canCount)         {             string minutes = ((int)timer / 60).ToString();             string seconds = (timer % 60).ToString("f2");             timer -= Time.deltaTime;             timerText.text = minutes + ":" + seconds;         }          else if (timer <= 0.0f && !doOnce)         {             canCount = false;             doOnce = true;             timerText.text = "0.00";             timer = 0.0f;         }    
	}

    public void OnDeath2()
    {
        isDead = true;

    }
}
