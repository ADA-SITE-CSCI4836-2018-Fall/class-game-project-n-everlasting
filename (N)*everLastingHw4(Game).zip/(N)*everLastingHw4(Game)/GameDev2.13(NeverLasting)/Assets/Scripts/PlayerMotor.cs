﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMotor : MonoBehaviour
{
    public Score objectScore;     public Timer objectTimer;

    public AudioClip farid;
    public AudioClip stone;
    public AudioClip power;
    public AudioClip crash;

    public AudioSource audios;

    private CharacterController controller;
    private Vector3 moveVector;

    public GameObject avatar1, avatar2;

    int whichAvatarIsOn = 1;

    private float speed = 5.0f;
    private float verticalVelocity = 0.0f;
    private float gravity = 12.0f;

    private bool isDead = false;

    // Use this for initialization
    void Start()
    {
        avatar1.gameObject.SetActive(true);
        avatar2.gameObject.SetActive(false);

        controller = GetComponent<CharacterController>();
        audios = GetComponent<AudioSource>();

    }

    // Update is called once per frame
    void Update()
    {

        if (isDead)
            return;


        moveVector = Vector3.zero;

        if (controller.isGrounded)
        {
            verticalVelocity = -0.5f;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }

        //X - Left - Right
        moveVector.x = Input.GetAxisRaw("Horizontal") * speed;

        //Y - Up - Down
        moveVector.y = verticalVelocity;

        //Z - Forward - Backward
        moveVector.z = speed;

        controller.Move(moveVector * Time.deltaTime);
    }

    public void SetSpeed(float modifier)
    {
        speed = 5.0f + modifier;
    }

    //It is being called every time our player hits something 
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {   
       
        if (hit.point.z > transform.position.z + (controller.radius / 2))
        {
            if (hit.gameObject.name == "Araz")
            {
                Destroy(hit.gameObject);
                audios.PlayOneShot(power);
                avatar1.gameObject.SetActive(false);
                avatar2.gameObject.SetActive(true);

                objectScore.score = objectScore.score * Mathf.Sqrt(2);
            }
            else if (hit.gameObject.name == "Emin")
            {
                Destroy(hit.gameObject);
                audios.PlayOneShot(power);
                avatar1.gameObject.SetActive(true);
                avatar2.gameObject.SetActive(false);

                objectTimer.timer = objectTimer.timer + 10/2;
                //if(hit.gameObject.name == "Car")
                //{
                //    Destroy(hit.gameObject);
                //}
                //else
                //{
                    
                //}

            }
            else if (hit.gameObject.name == "Samir")
            {
                Destroy(hit.gameObject);
                audios.PlayOneShot(power);
                objectScore.score = objectScore.score + Random.Range(20f, 200f);
                avatar1.gameObject.SetActive(true);
                avatar2.gameObject.SetActive(false);

            }
            else if (hit.gameObject.name == "Gulmammad")
            {
                Destroy(hit.gameObject);
                audios.PlayOneShot(power);
                speed = speed * 0.8f;
                gravity = gravity * 1.5f;
                avatar1.gameObject.SetActive(true);
                avatar2.gameObject.SetActive(false);
                //if(hit.transform.tag == "Player")
                //{
                //    Physics2D.IgnoreCollision()
                //}
                //if ( == "theobjectToIgnore")
                //{
                //    Physics.IgnoreCollision(theobjectToIgnore.collider, collider);
                //}

            }
            else if(hit.gameObject.name == "Farid")
            {
                audios.PlayOneShot(farid);
                //Destroy(hit.gameObject);
                Death();
                //objectScore.score = 0;
            }
            else if(hit.gameObject.name == "Stone")
            {
                audios.PlayOneShot(stone);
                Death();
            }
            else if(hit.gameObject.name == "Car")
            {
                audios.PlayOneShot(crash);
                Death();

            }
            else
            {

            }
        }
    }

    private void Death()
    {
        isDead = true;
        GetComponent<Score>().OnDeath();
    }
    public void SwitchAvatar()
    {

        // processing whichAvatarIsOn variable
        switch (whichAvatarIsOn)
        {

            // if the first avatar is on
            case 1:

                // then the second avatar is on now
                whichAvatarIsOn = 2;

                // disable the first one and anable the second one
                avatar1.gameObject.SetActive(false);
                avatar2.gameObject.SetActive(true);
                break;

            // if the second avatar is on
            case 2:

                // then the first avatar is on now
                whichAvatarIsOn = 1;

                // disable the second one and anable the first one
                avatar1.gameObject.SetActive(true);
                avatar2.gameObject.SetActive(false);
                break;
        }
    }
}
